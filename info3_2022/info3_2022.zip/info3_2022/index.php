<html lang="pt-bt">
<!--cabeçalho-->
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, inital-scale=1">
		<meta name="pagina de acesso" content="Bem Vindo!">
		<meta name="author" content="Diogo Sistemas">
		<link rel="icon" href="imagens/icon_70af72fb46d5677fd2b845069b0ced1f.ico">
		<title>...::: BEM VINDO :::...</title>
	</head>
	<style>
	body{
    animation: degrade 5s ease alternate infinite;
    background: linear-gradient(-130deg,rgb(60, 60, 179),black, rgb(69, 156, 156)) no-repeat;
    background-size: 300% 300%;
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    @keyframes degrade {
        0% {
            background-position: 0 50%;
        }
        50%{
            background-position: 100% 50%;
    
        }
        100% {
            background-position: 0 50%;
        }
    }


    
.c-loader {
    animation: is-rotating 1s infinite;
    border: 6px solid #484eaa;
    border-top-color: #50aeca;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    margin-top: 430px;
    margin-right: 100px;
    margin-left: 610px;
    position:fixed;
}

@keyframes is-rotating {
    to {
    transform: rotate(1turn)
    }
    
}

#style1 {
padding-top: 110px;



}
.key{
margin-top: 300px;
margin-right: 500px;
margin-left: 540px;
position:fixed;
font-size: 30px;
color: white;

}
.keye{
    margin-top: 350px;
    margin-right: 500px;
    margin-left: 580px;
    position:fixed;
    font-size: 30px;
    color: white;


}
.key3 {
    margin-top: 300px;
    margin-right: 500px;
    margin-left: 605px;
    position:fixed;
    font-size: 30px;
    color: white;
}
.key4 {
    margin-top: 300px;
    margin-right: 500px;
    margin-left: 670px;
    position:fixed;
    font-size: 30px;
    color: white;
}

</style>


	
	
	

	<!--js para o redirecionamento-->
	<script type="text/javascript">
	function redirectTime() {
	//window.location = "manutencao.php"
	window.location = "login_2.php"
	}
	</script>
	<!------------------>
	
	<!--conteúdo da página-->

	<body onload="setTimeout('redirectTime()', 5000)">
	
	<html>
<title>Carregando...</title>
       <h2 class="key">Seja </h2>
       <h2 class="key3">Bem </h2>
       <h2 class="key4">Vindo </h2>
       <h2 class="keye">Aguarde... </h2>
<div class="c-loader"></div>




   



					</html>