


<?php

phpinfo();

?>