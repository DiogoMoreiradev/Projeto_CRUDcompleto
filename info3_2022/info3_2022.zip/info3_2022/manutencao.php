
<html lang="pt-br">
<!--cabeçalho html-->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="pagina de acesso" content="Manutenção!">
    <meta name="author" content="Diogo Sistemas">
    <link rel="icon" href=""imagens/favicon.ico">
    <title>SISTEMA EM MANUTENÇÃO</title>
    <link href="css/signin.css" rel="stylesheet">
</head>
<!--------------------->
<!--estilo de ffonte e tamanho-->
<style type="text/css">
.style1 {
    font-family:Verdana, Arial, Helvetica, sans-serif;
    font-size: 12px;
}
</style>
<!-------------------->

<!--conteúdo da página-->
<body>
<!--container boostrap para ajuste do conteúdo na página-->
<div class="container">

	<!--tabela para organizar o conteúdo-->
<table width="457" border="0" align="center">
	<tr>
		<td><div align="center"><img src="imagens/manutencao.jpg" alt="logo"
		"width="800" height="600" /></div</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
		<td>&nbsp;</td>
	</tr>

</table
<!----------------------->

</div>
<!----------------------->
</body>
</html>